﻿/* 
Console.WriteLine("Bom dia");
Console.WriteLine("Escreva seu nome");
string nome = Console.ReadLine();
Console.WriteLine("Seu nome é" + nome);


float altura1, altura2;
Console.WriteLine("Coloque a altura 1");
altura1 = float.Parse(Console.ReadLine());
Console.WriteLine("Coloque a altura 2");
altura2 = float.Parse(Console.ReadLine());
float media = (altura1 + altura2) / 2;
if (media >= 1.70)
{
    Console.WriteLine("A media é " + media + "maior que 1.70");
}
else
{
    Console.WriteLine("A media" + media + "menor que 1.70");
}

// MEDIA 

Console.WriteLine("Digite a primeira nota");
double notaum = double.Parse(Console.ReadLine());
Console.WriteLine("Digite a segunda nota");
double notaDois = double.Parse(Console.ReadLine());

double media1 = (notaum + notaDois) / 2;
if (media1 >= 7)
{
    Console.WriteLine("Parabens sua media foi de " + media1 + "Voce foi aprovado");

}
else if (media1 >= 5)
{
    Console.WriteLine("Sua media foi de " + media1 + "Voce foi está de Recuperação");


}
else
{
    Console.WriteLine("VocÊ infelizmente foi reprovado, sua media foi de " + media1);
} 

//Numero positivo ou negativo Leia um numero e diga se é positivo ou negativo ou zero
Console.WriteLine("Coloque um numero ");
int n1 = int.Parse(Console.ReadLine());


if (n1 > 0)
{
    Console.WriteLine("Este numero é Positivo");
}
else if (n1 < 0)
{
    Console.WriteLine("Este numero é negativo");
}
else
{
    Console.WriteLine("Esse numero é zero ");
}
 */
// Se é maior de idade
Console.WriteLine("Coloque um idade ");
int idade = int.Parse(Console.ReadLine());


if (idade > 18)
{
    Console.WriteLine("Maior de idade");
}
else 
{
    Console.WriteLine("Menor de idade");
}

// Par ou Impar
Console.WriteLine("Coloque um numero ");
int n2 = int.Parse(Console.ReadLine());


if (n2 % 2 == 0)
{
            Console.WriteLine("O número é par");
}
else
{
            Console.WriteLine("O número é ímpar.");
}

// Calculadora Simples
Console.WriteLine("Digite um numero");
int numero = int.Parse(Console.ReadLine());

Console.Write("Digite o operador (+, -, *, /): ");
char op = char.Parse(Console.ReadLine());

Console.WriteLine("Digite um outro numero");
int numero2 = int.Parse(Console.ReadLine());

 int resultado = 0;

        if (op == '+')
        {
            resultado = numero + numero2;
            Console.WriteLine("Resultado: " + resultado);
        }
        else if (op == '-')
        {
            resultado = numero - numero2;
            Console.WriteLine("Resultado: " + resultado);
        }
        else if (op == '*')
        {
            resultado = numero * numero2;
            Console.WriteLine("Resultado: " + resultado);
        }
        else if (op == '/')
        {
            if (numero2 != 0)
            {
                resultado = numero / numero2; // divisão inteira
                Console.WriteLine("Resultado: " + resultado);
            }
            else
            {
                Console.WriteLine("Erro: divisão por zero!");
            }
        }
        else
        {
            Console.WriteLine("Operador inválido!");
        }


//Categoria de idade 
// Leia a idade e classifique 0 a 12 criança
// 13 a 17 - adolescente
// 18 a 59 adulto
// 60 ou + idoso
Console.WriteLine("Coloque um idade ");
int idade1 = int.Parse(Console.ReadLine());


 if (idade >= 0 && idade <= 12)
{
    Console.WriteLine("Criança");
}
else if (idade1 >= 13 && idade1 <= 17)
{
    Console.WriteLine("Adolescente");
}
else if (idade1 >= 18 && idade1 <= 59)
{
    Console.WriteLine("Adulto");
}

else if (idade1 >= 60)
{
    Console.WriteLine("Idoso");
}
else
{
    Console.WriteLine("Idade invalida");
}