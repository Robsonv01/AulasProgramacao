﻿//1
// Crie uma variável para armazenar seu nome e exiba na tela:
// Olá, meu nome é <nome>.
Console.WriteLine("Olá, Mundo! Robs");
string nome = Console.ReadLine();
Console.WriteLine("Olá Meu nome é " + nome);

//2
// Soma Simples
// Declare duas variáveis inteiras, atribua valores e exiba o resultado da soma.

Console.WriteLine("Escreva um numero");
int a = int.Parse(Console.ReadLine());
Console.WriteLine("Escreva outro numero");
int b = int.Parse(Console.ReadLine());
Console.WriteLine("A soma dos numeros é " + (a + b));

//3
// Soma Simples
// Declare duas variáveis inteiras, atribua valores e exiba o resultado da soma.


Console.WriteLine("Coloque um numero para multiplicação: ");
int c = int.Parse(Console.ReadLine());
Console.WriteLine("Coloque outro numero para multiplicação: ");
int d = int.Parse(Console.ReadLine());
Console.WriteLine("multiplicação: " + (c * d));

//4 
// Idade no Próximo Ano
// Crie uma variável para sua idade e exiba:
// "No próximo ano, terei X anos".

Console.WriteLine("Coloque sua idade ");
int idade = int.Parse(Console.ReadLine());
Console.WriteLine("Sua idade é " + idade);
Console.WriteLine("Coloque sua idade ");
int idade2 = int.Parse(Console.ReadLine());
Console.WriteLine("No próximo ano, terei " + (idade2 + 1) + " anos.");

//5 
// Área do Retângulo
// Crie duas variáveis largura e altura e calcule a área (largura × altura).
 
 Console.WriteLine("Coloque a altura");
int altura = int.Parse(Console.ReadLine());
 Console.WriteLine("Coloque a Largura");
int largura = int.Parse(Console.ReadLine());
Console.WriteLine("A area do retangulo é  " + (largura * altura));

//6
// Conversão de Temperatura
// Crie uma variável para armazenar a temperatura em Celsius e exiba em Fahrenheit.
// Fórmula: (celsius * 9/5) + 32.

Console.WriteLine("Coloque a temperatura");
float temperatura = float.Parse(Console.ReadLine());
Console.WriteLine("A temperatura em Fahrenheit é " + (temperatura * 9 / 5 + 32));

//7
// Troca de Valores
// Crie duas variáveis, a e b, troque seus valores usando uma variável auxiliar.

Console.WriteLine("Coloque uma variavel x :");
int x = int.Parse(Console.ReadLine());
Console.WriteLine("Coloque uma variavel z :");
int z = int.Parse(Console.ReadLine());

int guardv = x;
x = z;
z = guardv;
Console.WriteLine("Trocando a variavel");
Console.WriteLine("A variaveis de x agora é  " + x + " e de z é" + z);

//8
// Concatenando Nome e Sobrenome
// Crie duas variáveis nome e sobrenome e exiba o nome completo.

Console.WriteLine("Coloque seu nome");
string nome2 = Console.ReadLine();
Console.WriteLine("Coloque seu Sobrenome");
string sobrenome = Console.ReadLine();
Console.WriteLine($"Olá {nome2} {sobrenome}");

//9
// Média de Três Números
// Crie três variáveis double, calcule a média e exiba o resultado.
Console.WriteLine("Coloque um numero");
double n1 = double.Parse(Console.ReadLine());
Console.WriteLine("Coloque segundo numero");
double n2 = double.Parse(Console.ReadLine());
Console.WriteLine("Coloque terceiro numero");
double n3 = double.Parse(Console.ReadLine());
Console.WriteLine($"A media é  {(n1  + n2 + n3) / 3}");

//10
// Calculando Desconto
// Crie variáveis para preco e desconto e calcule o preço final.

Console.WriteLine("Coloque o valor para o desconto");
float valor = float.Parse(Console.ReadLine());
Console.WriteLine($"Desconto de 10%: {valor * 0.90}");

//11
// Quadrado de um Número
// Declare um número inteiro e exiba o valor elevado ao quadrado.
Console.WriteLine("Coloque um valor para elevar ao quadrado: ");
int valorQuadrado = int.Parse(Console.ReadLine());
Console.WriteLine($"Valor ao quadrado: {valorQuadrado * valorQuadrado}");

//12
// Restante da Divisão
// Crie duas variáveis inteiras e exiba o resto da divisão (%).

Console.WriteLine("Coloque o dividendo: ");
int dividendo = int.Parse(Console.ReadLine());
Console.WriteLine("Coloque o divisor: ");
int divisor = int.Parse(Console.ReadLine());
Console.WriteLine($"Resto da divisao: {dividendo % divisor}");

//13
// Conversão de Anos para Meses e Dias
// Crie uma variável para idade em anos e calcule quantos meses e dias isso representa (considere 365 dias por ano).
Console.WriteLine("Coloque os anos");
int ano = int.Parse(Console.ReadLine());
int meses = ano * 12;
Console.WriteLine($"Meses: {meses} Dias: {meses * 365}");

//14
// Dobro e Metade
// Declare um número e exiba seu dobro e sua metade.
Console.WriteLine("Coloque um numero: ");
int numero = int.Parse(Console.ReadLine());
Console.WriteLine($"Dobro: {numero * 2} Metade: {numero / 2}");

//15
// Valor com Acréscimo
// Crie uma variável com um valor inicial e acrescente 15% sobre ele, exibindo o resultado.
Console.WriteLine("Coloque o valor para o acrescimo: ");
float valorAcrescimo = float.Parse(Console.ReadLine());
Console.WriteLine($"Valor com acrescimo de 15%: {valorAcrescimo * 1.15}");















