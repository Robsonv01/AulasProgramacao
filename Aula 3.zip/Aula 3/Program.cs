﻿//1. Crie duas variáveis largura e altura e calcule o perímetro (2 × (largura + altura)).

using System.Xml.Serialization;

Console.WriteLine("Coloque a altura");
int altura = int.Parse(Console.ReadLine());
 Console.WriteLine("Coloque a Largura");
int largura = int.Parse(Console.ReadLine());
Console.WriteLine($"Perimetro {2 * (largura * altura)}");

//2. Crie uma variável com a distância em quilômetros e exiba o valor em metros.
 Console.WriteLine("Coloque um  valor de KM");
int KM = int.Parse(Console.ReadLine());
Console.WriteLine("O valor em metros é" + (KM * 1000));

//3. Crie duas variáveis inteiras e exiba:
//O resultado da divisão inteira
//O resultado da divisão real (com casas decimais).


Console.WriteLine("Coloque um numero ");
int n1 = int.Parse(Console.ReadLine());
Console.WriteLine("Coloque outro numero");
int n2 = int.Parse(Console.ReadLine());
Console.WriteLine("o resultado da divisão é inteira: " + (n1 / n2));
Console.WriteLine("o resultado da divisão real é: " +  ((double)n1/n2)); 

// 4. Crie uma variável inteira e exiba se o número é par ou ímpar.
Console.WriteLine("Coloque um numero ");
int numero = int.Parse(Console.ReadLine());
if (numero % 2 == 0)
{
    Console.WriteLine("É par");

}
else
{
    Console.WriteLine("É impar");
}

//5 Crie variáveis para peso (kg) e altura (m) e calcule o IMC:
// IMC = peso / (altura * altura)
Console.WriteLine("Coloque o peso(em kg): ");
float kg = float.Parse(Console.ReadLine()); 
Console.WriteLine("Coloque a altura(em m): ");
float altura = float.Parse(Console.ReadLine());
Console.WriteLine($"Seu imc é {kg / (altura * altura)}");


//6. Crie variáveis para nome, idade e cidade, e exiba:
// Meu nome é <nome>, tenho <idade> anos e moro em <cidade>."
Console.WriteLine("Coloque sue nome: ");
string nome = Console.ReadLine();
Console.WriteLine("Coloque sua idade: ");
int idade = int.Parse(Console.ReadLine());
Console.WriteLine("Coloque a cidade onde mora: ");
string cidade = Console.ReadLine();
Console.WriteLine($"Meu nome é {nome}, tenho {idade} anos e moro em {cidade}.");

//7 Crie uma variável com a quantidade total de minutos e exiba quantas horas e minutos representam.
// Exemplo: 130 minutos = 2 horas e 10 minutos.
Console.WriteLine("Coloque o valor em minutos");
int minutos = int.Parse(Console.ReadLine());
int horas = minutos / 60;
int minutosSubtrair = horas * 60;
int minutoscertos = minutos - minutosSubtrair;
Console.WriteLine($"{horas} horas e {minutoscertos} minutos ");

//8. Crie uma variável inteira e exiba o número anterior e o próximo.
//Exemplo: Número 10 → Antecessor: 9 | Sucessor: 11.
Console.WriteLine("Coloque um valor");
int nu1 = int.Parse(Console.ReadLine());
Console.WriteLine($"{nu1 + 1} Sucessor , e o Antecessor é {nu1 - 1}");

//9. Crie variáveis para capital, taxa e tempo, e calcule os juros simples:
//J = (capital × taxa × tempo) / 100.
Console.WriteLine("Coloque uma capital");
int capital = int.Parse(Console.ReadLine());
Console.WriteLine("Coloque uma taxa");
int taxa = int.Parse(Console.ReadLine());
Console.WriteLine("Coloque o tempo");
int tempo = int.Parse(Console.ReadLine());

int calculo = (capital * taxa * tempo) / 100;
Console.WriteLine("O juro simples é " + (calculo));

//10. Crie uma variável em reais e exiba o valor convertido em dólares (use uma taxa fixa, ex: 1 dólar = 5 reais).
Console.WriteLine("Coloque o valor em reais ");
float reais = float.Parse(Console.ReadLine());
Console.WriteLine(" O valor em reais é " + (reais * 5));

//11. Crie variáveis para distância (km) e tempo (h), e calcule a velocidade média:
// Velocidade = distância / tempo.
Console.WriteLine("Coloque a distancia(em KM): ");
float km11 = float.Parse(Console.ReadLine()); 
Console.WriteLine("Coloque o tempo(em horas): ");
float horas11 = float.Parse(Console.ReadLine());
float velocidade = km11 / horas11;
Console.WriteLine($"A velocidade media é {velocidade}");

//12 Crie uma variável inteira (que pode ser negativa) e exiba seu valor absoluto.
Console.WriteLine("Coloque um numero para mostrar seu valor absoluto: ");
int n12 = int.Parse(Console.ReadLine());
int valorAbsoluto = Math.Abs(n12);
Console.WriteLine($"Seu valor {n12} ele absoluto {valorAbsoluto}"); 
 
//13 Crie uma variável inteira e exiba o número elevado ao cubo.

Console.WriteLine("Coloque o numero para elevar ao cubo: ");
int n13 = int.Parse(Console.ReadLine());
Console.WriteLine($"Seu valor ao cubo é {Math.Pow(n13, 3)}");

//14. Crie variáveis para aulas assistidas e aulas totais, e calcule a porcentagem de presença do aluno.

Console.WriteLine("Coloque o total de aulas: ");
int totalAulas = int.Parse(Console.ReadLine());
Console.WriteLine("Coloque as aulas assitidas: ");
int aulasAssistidas = int.Parse(Console.ReadLine());
int calculo14 = (aulasAssistidas / totalAulas) * 100;
Console.WriteLine($"A porcentagem de aulas assistidas é {calculo14}");

//15 Crie variáveis para horas, minutos e segundos, e exiba o total em segundos.
Console.WriteLine("Coloque as horas");
int horas1 = int.Parse(Console.ReadLine());
Console.WriteLine("Coloque os minutos");
int min1 = int.Parse(Console.ReadLine());
Console.WriteLine("Coloque os segundos");
int segundos = int.Parse(Console.ReadLine());

int horasParaMinutos = horas1 * 60;
int HMinutosParaSegundos = horasParaMinutos * 60;

int MinutosParaSegundos = min1 * 60;
int soma = HMinutosParaSegundos + MinutosParaSegundos + segundos;
Console.WriteLine("O total em segundo é" + (soma));

//EXEMPLO
double n11, n22;
Console.WriteLine("Entre com a 1ª nota");
n11 = double.Parse(Console.ReadLine());
Console.WriteLine("Entre com a 2ª nota");
n22 = double.Parse(Console.ReadLine());
double soma = n11 + n22;
double media = soma / 2;
Console.WriteLine("O valor da média é " + (media));