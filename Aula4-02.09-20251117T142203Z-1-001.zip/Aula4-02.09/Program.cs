﻿/* // See https://aka.ms/new-console-template for more information
Console.WriteLine("Bom dia");
Console.WriteLine("Coloque seu nome");
string nome;
nome = Console.ReadLine();
Console.WriteLine("Seu nome é " + nome);
float altura1, altura2;
Console.WriteLine("Coloque a altura1");
altura1 = float.Parse(Console.ReadLine());
Console.WriteLine("Coloque a altura 2");
altura2 = float.Parse(Console.ReadLine());
 float media = (altura1 + altura2)/2;
if (media >= 1.70)
{
    Console.WriteLine("A media é " + media + "maior que 1.70");
}
else
{
    Console.WriteLine("A media" + media + "menor que 1.70");
}
// Exemplo
int idade;
string nome;
bool ensinoMedio = true;

Console.WriteLine("Coloque sue nome: ");
nome = Console.ReadLine();

Console.WriteLine("Entre com sua idade");
idade = int.Parse(Console.ReadLine());

Console.WriteLine("Está cursando o  ensino medio?");
string reposta = Console.ReadLine();
if (reposta != "sim")
{
    ensinoMedio = false;
}

if (idade >= 16 && ensinoMedio)
{
    Console.WriteLine("Voce não pode fazer SENAI ");
}
else
{
    Console.WriteLine("Voce pode fazer SENAI ");
} */

// Passou + de 10 min usando if else switch case
Console.WriteLine("Coloque o tempo");
int tempo = int.Parse(Console.ReadLine());
 
if (tempo >= 10)
{
    Console.WriteLine("Pegar um taxi");
}
else
{
    Console.WriteLine("Aguardar");
}

// Se possui 18 usando o or && 
 Console.Write("Digite sua idade: ");
        int idade = int.Parse(Console.ReadLine());

        Console.Write("Possui autorização do responsável? (s/n): ");
string autorizacao = Console.ReadLine();

        if (idade >= 18 && autorizacao == "s")
        {
            Console.WriteLine("Entrada permitida.");
        }
        else 
        {
            Console.WriteLine("Entrada não permitida.");
        }
