﻿Console.WriteLine("Escreva seu nome");
string nome = Console.ReadLine();

Console.WriteLine("Escreva sua idade");
int idade = int.Parse(Console.ReadLine());

bool presenca = true;

Console.WriteLine("Escreva sua altura");
double altura = double.Parse(Console.ReadLine());

Console.WriteLine("Escreva seu peso");
float peso = float.Parse(Console.ReadLine());

double imc = peso / (altura * altura);
Console.WriteLine("Seu imc é  " + imc);

if (imc > 40)
{
    Console.WriteLine("Obesidade Grave");
}
else if (imc > 30 && imc < 39)
{
    Console.WriteLine("obsidade");
}
else if (imc > 25 && imc < 29)
{
    Console.WriteLine("SobrePeso");
}
else if (imc > 18.5 && imc < 24)
{
    Console.WriteLine("Normal");
}
else if (imc < 18.5)
{
    Console.WriteLine("Magreza");
}   