﻿Console.WriteLine("Entre com o primeiro número");
double notaUm = double.Parse(Console.ReadLine());

Console.WriteLine("Entre com o segundo número");
double notaDois = double.Parse(Console.ReadLine());

double media = (notaUm + notaDois) / 2;

Console.WriteLine("A media é " + media);
